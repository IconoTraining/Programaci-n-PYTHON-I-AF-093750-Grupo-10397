nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for item in nombres :
    print(item)
print("------- FIN -------")

''' rangos '''
# Mostrar los numeros del 0 al 9
for numero in range(10):  # Rango empieza en 0 y termina num-1
    print(numero)
print("------- FIN -------")

# Mostrar los numeros del 1 al 10
for numero in range(1, 11):  # Rango empieza en 1 y termina num-1
    print(numero)
print("------- FIN -------")

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2):  # Rango empieza en 0 y termina num-1, step=2
    print(numero)
print("------- FIN -------")

# Mostrar los numeros del 10 al 0 de 2 en 2
for numero in range(10, -1, -2):  # Rango empieza en 10 y termina num-1, step=-2
    print(numero)
print("------- FIN -------")

# Mostrar los nombres con rango
for i in range(len(nombres)):
    print(nombres[i])
print("------- FIN -------")