'''
    Solicitar una letra (l,m,x,j,v,s,d) y decir a que dia
    de la semana corresponde.
    El usuario puede escribir en mayuscula o miniscula
    Ideas: or, upper, lower
'''

letra = input("Introduce dia de la semana:  ")

if letra == 'l' or letra == 'L':
    print("Es lunes")
elif letra == 'm' or letra == 'M':
    print("Es martes")
elif letra.lower() == 'x':
    print("Es miercoles")
elif letra.upper() == 'J':
    print("Es jueves")
elif letra == 'v' or letra == 'V':
    print("Es viernes")
elif letra.lower() == 's':
    print("Es sabado")
elif letra.upper() == 'D':
    print("Es domingo")
else:
    print("Dia desconocido")