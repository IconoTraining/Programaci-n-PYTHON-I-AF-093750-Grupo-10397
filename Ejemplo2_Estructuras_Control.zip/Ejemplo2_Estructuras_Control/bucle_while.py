# mostrar los numeros del 1 al 10
num = 1
while num <= 10:
    print(num)
    num += 1
print("-------- FIN --------")


# recorrer una lista
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
i = 0
while i < len(nombres):
    print(nombres[i])
    i += 1
print("-------- FIN --------")  
    