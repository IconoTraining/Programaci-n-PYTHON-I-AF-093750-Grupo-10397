# La funcion reduce le pasamos una coleccion y
# devuelve un solo resultado
# La funcion recibe 2 argumentos:
#    - el primero actua como acumulador
#    - el segundo es el valor recibido
# sintaxis:   reduce(funcion, coleccion)

''' Para utilizar reduce hay que importarlo  '''
from functools import reduce


''' Ejemplo 1 '''
numeros = [3,8,4,15,30]

def sumar(acum, num):
    return acum + num

print("Suma:", reduce(sumar, numeros))


''' Ejemplo 2 '''
nombres = ['Juan', 'Maria', 'Pablo']

def concatenar(resultado, nombre):
    return resultado.upper() + "-" + nombre.upper()

print(reduce(concatenar, nombres))