# Sintaxis:  lambda parametros: que hacemos con esos parametros

''' ***************** map **************** '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numerosDobles = list(map(lambda numero: numero*2, numeros))
print(numerosDobles)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Adolfo=7.1)
nuevasNotas = dict(map(lambda item: (item[0], item[1] + 1), alumnos.items()))
print(nuevasNotas)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad) -> None:   
        self.nombre = nombre
        self.edad = edad

    def mostrarInfo(self):
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
personas = [Persona("Juan",27), Persona("Maria",19), Persona("Pedro",22)]
personas = list(map(lambda persona: Persona(persona.nombre.upper(), persona.edad + 1), personas))

for person in personas:
    person.mostrarInfo()


''' *************** filter *************** '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numerosPares = list(filter(lambda numero: numero % 2 == 0, numeros))
print(numerosPares)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=3.3, Adolfo=7.1)
alumnosSuspensos = dict(filter(lambda item: item[1] < 5, alumnos.items()))
print(alumnosSuspensos)


# Ejemplo 3
personas = [Persona("Juan",17), Persona("Maria",19), Persona("Pedro",12)]
menores = list(filter(lambda persona: persona.edad < 18, personas))
for person in menores:
    person.mostrarInfo()


''' *************** reduce *************** '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]
print("Suma:", reduce(lambda acum, num: acum + num, numeros))


# Ejemplo 2
nombres = ['Juan', 'Maria', 'Pablo']
print(reduce(lambda resultado, nombre: resultado.upper() + "-" + nombre.upper(), nombres))