# Primera forma de importar el modulo
'''
import persona

# sintaxis: modulo.Clase
juan = persona.Persona("Juan", 45)
juan.mostrarInfo()
'''


# Segunda forma
'''
from persona import Persona
juan = Persona("Juan", 45)
juan.mostrarInfo()
'''

# Tercera forma
from persona import Persona as Pers
juan = Pers("Juan", 45)
juan.mostrarInfo()