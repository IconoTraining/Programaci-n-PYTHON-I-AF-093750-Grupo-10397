# Funcion con un numero variable de argumentos
def sumar(*numeros):
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(7))
print(sumar(4,9))
print(sumar(2,5,7))
print(sumar(1,8,4,9))

# Funcion que recibe el nombre y las notas de un alumno
# utilizando la funcion sumar() calculamos la media
# devuelve el nombre en mayusculas y la media de las notas
def calcularNotas(*notas, nombre):
    notaMedia = sumar(*notas) / len(notas)
    return nombre.upper(), notaMedia

print(calcularNotas(4,8,3,6, nombre="Juan"))
print(calcularNotas(7,9, nombre="Maria"))
print(calcularNotas(5,6,5,4,8, nombre="Pedro"))

