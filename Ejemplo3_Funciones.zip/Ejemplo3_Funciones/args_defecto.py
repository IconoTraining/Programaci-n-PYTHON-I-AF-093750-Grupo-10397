print(3,4,sep=" - ", end=" FIN\n")

# Funcion con argumentos opcionales que tienen valor por defecto
def datosTrabajador(nombre, sueldo=21000, estadoCivil="Solter@"):
    return nombre + " su sueldo: " + str(sueldo) + " esta " + estadoCivil

print(datosTrabajador("Pepe"))
print(datosTrabajador("Antonio", 35000))
# print(datosTrabajador(sueldo=32000))  Error al no poner el nombre obligatorio

# Interpreta que el sueldo es Separado
print(datosTrabajador("Angel", "Separado"))
print(datosTrabajador("Angel", estadoCivil="Separado"))

# Lo interpreta bien al seguir el orden
print(datosTrabajador("Angel", 43000))


# Funcion con argumento variable y argumentos por defecto
def concatenar(*datos, separador=" | "):
    return separador.join(datos)

print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo"))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador=","))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador="-"))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador=" / "))