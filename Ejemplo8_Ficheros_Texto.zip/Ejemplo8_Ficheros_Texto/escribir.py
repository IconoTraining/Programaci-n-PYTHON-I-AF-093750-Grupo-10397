# Abrir el fichero en modo escritura
fichero = open("Ejemplo8_Ficheros_Texto/fichero_escritura.txt", 'wt', encoding="utf-8")

for i in range(3):
    texto = input("Introduce texto: ")
    fichero.write(texto + "\n")
    
# cerrar el fichero
fichero.close()
