# tuplas: colecciones ordenadas pero inmutables
# si que permiten elementos duplicados
# se crean con ()
# Ejemplos: dias de la semana, meses del año, estado civil, puntos cardinales

dias = ("lunes","martes","miercoles","jueves","viernes","sabado","domingo")
print(type(dias))  # tuple

# Mostrar la tupla
print(dias)

# Recorrer una tupla
for dia in dias:
    print(dia)
    
# Mostrar el miercoles
print(dias[2])

# Ordenar tupla
print(sorted(dias))
print(sorted(dias, reverse=True))

# Intento borrar el lunes
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]  

# Intentamos concatenar tuplas
# otra_tupla = dias + ('otro_sabado') # TypeError: can only concatenate tuple (not "str") to tuple
otra_tupla = dias + ('otro_sabado',) # con una coma si funciona. Le hacemos creer qie son varios elementos
otra_tupla = dias + ("otro_sabado", "otro_domingo")
print(otra_tupla)

# Intento agregar elemento
# TypeError: can only concatenate tuple (not "str") to tuple
# otra_tupla.__add__('aaaaaaa')
# print(otra_tupla) 

# Intento modificar un elemento
# TypeError: 'tuple' object does not support item assignment
# dias[0] = dias[0].upper()

# contar cuantos lunes hay?
print(dias.count('lunes'))

# Buscar en que indice esta el viernes
print(dias.index('viernes'))

# longitud
print(len(dias))
print(dias.__len__())

for i in range(len(dias)):
    print(dias[i])