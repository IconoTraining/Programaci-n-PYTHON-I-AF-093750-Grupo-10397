# conjuntos: colecciones sin orden, no podemos usar indices
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada
# Permite elementos de diferentes tipos
# Se crean con {}

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas))  # set

# Mostrar todas las frutas
print(frutas)

# Comprobar si tenemos fresa en el conjunto
print('fresa' in frutas)

# agregar fresa
frutas.add('fresa')
print(frutas)

# eliminar platano
frutas.remove("platano")
print(frutas)

# longitud del conjunto
print(len(frutas))
print(frutas.__len__())

''' ******************* operaciones con conjuntos *************** '''
numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes entre ambos
print(numeros1.intersection(numeros2))
print(numeros1 & numeros2)

# diferencia de conjuntos: mostrar los elementos de un conjunto que no estan en el otro
# Mostrar los elementos de numeros1 que no estan en numeros2
print(numeros1.difference(numeros2))
print(numeros1 - numeros2)

# Mostrar los elementos de numeros2 que no estan en numeros1
print(numeros2.difference(numeros1))
print(numeros2 - numeros1)

# que elementos estan fuera de la interseccion
print(numeros1.symmetric_difference(numeros2))
print(numeros1 ^ numeros2)

# borrar los elementos de numeros1 que esten en numeros2
numeros1.difference_update(numeros2)
print(numeros1)
print(numeros2)

''' *****************  compresion **************** '''
def filtrar():
    y = set()   # crear un conjunto vacio
    for letra in 'abracadabra':
        if letra not in 'abc':
            y.add(letra)
    return y

resultado = filtrar()
print(resultado)

# Con compresion podemos hacer lo mismo en una sola linea
resultado = { letra  for letra in 'abracadabra'  if letra not in 'abc' }
print(resultado)