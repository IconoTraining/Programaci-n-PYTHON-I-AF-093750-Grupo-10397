# diccionarios: los elementos son key:value
# las claves no se pueden repetir pero los value si
# se crean con {}

# Si repito la clave se sobreescribe el valor
alumnos = {"Juan":6.4, "Maria":8.3, "Luis":6.4, "Adolfo":7.1, "Maria":9.3}
print(type(alumnos)) # dict
print(alumnos)

# Mostrar solo las claves
print(alumnos.keys())

# Mostrar solo los values
print(alumnos.values())

# Mostrar si Maria  esta en el diccionario
print("Maria" in alumnos)

# Acceder a los alementos por su clave
print(alumnos['Maria'])  # me devuelve la nota
print(alumnos.get('Maria'))

# Eliminar a Adolfo
del alumnos['Adolfo']
# alumnos.__delitem__('Adolfo')   # otra forma
print(alumnos)

# Agregar nuevo alumno
alumnos['Pedro'] = 4.7
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:   # solo obtengo las claves
    print(alum, alumnos[alum])
    
for alum in alumnos.items():  # cada alum es una tupla
    print(alum)
    
for clave, valor in alumnos.items():
    print(clave, valor)
    
# otras formas de crear diccionarios
otro = dict([("Juan",6.4), ("Maria",8.3), ("Adolfo",7.1)]) # lista de tuplas
print(otro)

otroMas = dict(Juan='Aprobado', Maria=8.3, Adolfo=7.1)
print(otroMas)