# listas: colecciones ordenadas de elementos
# en todas las colecciones, los elementos pueden ser de diferentes tipos
# permite tener elementos duplicados
# Se crean con []

colorR = 'rojo'
colorV = 'verde'
colorA = 'azul'
colores = [colorR, colorV, colorA]

#colores = ['rojo','verde','azul']
print(type(colores))   #list

# Ordenar una lista
print(sorted(colores))  # no modifica la lista, se debe asignar colores = sorted(colores)
print(sorted(colores, reverse=True))  # Orden descendente
print(colores)

# Mostrar el color verde
print(colores[1])

# Borrar el color azul (posicion)
del colores[2]
print(colores)

# concatenar a otra lista
masColores = ['blanco', 'negro', 'rosa', 'azul']
nuevaLista = colores + masColores
print(nuevaLista)

# Borrar el color rosa (elemento)
nuevaLista.remove('rosa')  # solo el primero que encuentra
print(nuevaLista)

# Otra forma de borrar por indice
nuevaLista.__delitem__(4)
print(nuevaLista)

# Añadir un elemento al final
nuevaLista.append('naranja')
print(nuevaLista)

# Insertar un elemento en una posicion especifica
nuevaLista.insert(0, 'marron')
print(nuevaLista)

# Como podemos tener elementos duplicados
# Contar cuantos color blanco tengo
print(nuevaLista.count('blanco'))

# Mostrar el indice donde se encuentra el color blanco
print(nuevaLista.index('blanco'))     # 3
# print(nuevaLista.index('blanco', 4))  # buscar a partir del indice encontrado

# longitud de la lista
print(len(nuevaLista))
print(nuevaLista.__len__())

# Mostrar el ultimo elemento de la lista
print(nuevaLista[len(nuevaLista) - 1])
print(nuevaLista[ - 1])

# Mostrar el penultimo
print(nuevaLista[ - 2])

# Mostrar los dos ultimos
print(nuevaLista[-2 :])

# Mostrar desde la posicion 2 a la 4
print(nuevaLista[2 : 4])  # El ultimo en rango no se incluye

# Mostrar desde la posicion 0 a la 4
print(nuevaLista[ : 4])

# Mostrar todos 
print(nuevaLista[ : ])

# Mostrar desde la posicion 4 a la 2.
print(nuevaLista[4 : 2])  # En orden inverso no funciona, devuelve lista vacia

# borrar todos los elementos de la lista
nuevaLista.clear()
print(nuevaLista)
