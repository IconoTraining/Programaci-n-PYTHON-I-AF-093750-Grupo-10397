'''
    En este fichero creamos la BBDD y la tabla
'''

import sqlite3

# crear la BBDD
# Abrir la conexion y si no existe la BBDD se crea
conexion = sqlite3.connect("Ejemplo10_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla
cursor.execute("CREATE TABLE PRODUCTOS (codigo INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)")

# IMPORTANTE HACER EL COMMIT
conexion.commit()

# cerrar la conexion
conexion.close()