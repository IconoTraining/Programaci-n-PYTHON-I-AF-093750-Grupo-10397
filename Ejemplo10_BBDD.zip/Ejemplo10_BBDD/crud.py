# CRUD
# C -> Create -- Insert
# R -> Read   -- Select
# U -> Update -- Update
# D -> Delete -- Delete

import sqlite3

# Abrir la conexion
conexion = sqlite3.connect("Ejemplo10_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()


''' ******************** Insertar datos ********************* '''
# insertar un registro
#cursor.execute("INSERT INTO PRODUCTOS VALUES (1, 'Pantalla de 17 pulgadas', 89.95)")

# insertar varios registros a la vez
lista = [(2, 'Teclado', 29.40),(3, 'Impresora', 74.25),(4, 'Raton', 18.90),(5, 'Scanner', 102.85)]
sql = "INSERT INTO PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)

# Es importante hacer el commit
conexion.commit()

''' ******************** Consultas ********************* '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall() # recogemos todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

# mostrar los que tienen un precio superior a 50€
cursor.execute("select * from PRODUCTOS where precio > 50 order by precio desc")
productos = cursor.fetchall() # recogemos todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

# consultar todos los productos que comiencen por letra R
cursor.execute("select * from PRODUCTOS where descripcion LIKE 'R%' ")
productos = cursor.fetchall() # recogemos todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")


''' ******************** Modificar datos ********************* '''
cursor.execute("UPDATE PRODUCTOS SET precio=100.00 where descripcion='Impresora' ")
conexion.commit()


''' ******************** Borrar registros ********************* '''
cursor.execute("DELETE FROM PRODUCTOS where codigo=1 ")
conexion.commit()

# Cerrar la conexion
conexion.close()