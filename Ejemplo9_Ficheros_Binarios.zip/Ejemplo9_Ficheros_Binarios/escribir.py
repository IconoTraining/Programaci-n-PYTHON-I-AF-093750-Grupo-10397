import pickle

nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
fichero = open("Ejemplo9_Ficheros_Binarios/binario.pckl", 'wb')
pickle.dump(nombres, fichero)
fichero.close()