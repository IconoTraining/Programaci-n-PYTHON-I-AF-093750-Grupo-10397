class Direccion:
    def __init__(self, calle, numero, poblacion):
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def mostrar(self):
        # Mayor, 5 (Madrid)
        return self.calle + ", " + str(self.numero) + " (" + self.poblacion + ")"


class Persona:
    def __init__(self, nombre, edad, direccion=Direccion("calle",1,"Poblacion")) -> None:   
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion

    def mostrarInfo(self):
        print("Hola, me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion.mostrar()))
        
        
# Crear objetos de Persona
juan = Persona("Juan", 27)
juan.mostrarInfo()

maria = Persona("Maria", 35, Direccion("Diagonal", 218, "Barcelona"))
maria.mostrarInfo()

dir = Direccion("Mayor", 5, "Madrid")
juan.direccion = dir
juan.mostrarInfo()

# Cambiar el numero de Maria
maria.direccion.numero = 28
maria.mostrarInfo()