class Animal:  
    def __init__(self, nombre, edad) -> None:   
        self.nombre = nombre
        self.edad = edad

    def mostrarInfo(self):
        return "Nombre: " + self.nombre + " Edad: " + str(self.edad)


class ProductoVenta:  
    def __init__(self, codigo, precio) -> None:   
        self.codigo = codigo
        self.precio = precio

    def mostrarInfo(self):
        return "Codigo: " + self.codigo + " Precio: " + str(self.precio)


# herencia multiple
class Perro(Animal, ProductoVenta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo) -> None:
        Animal.__init__(self,nombre, edad)
        ProductoVenta.__init__(self,codigo, precio)
        self.vacunado = vacunado
        self.sexo = sexo
        
    def info(self):
        return Animal.mostrarInfo(self) + ProductoVenta.mostrarInfo(self) + " Vacunado: " + str(self.vacunado) + " Sexo:" + self.sexo


# Crear una instancia de Perro
perro = Perro("Fifi", 3, "PE-001", 249.50, True, "Macho")
print(perro.info())