class Persona:  
    def __init__(self, nombre, edad) -> None:   
        self.nombre = nombre
        self.edad = edad

    def mostrarInfo(self):
        return "Hola, me llamo " + self.nombre + " y tengo " + str(self.edad) + " años"


class Empleado(Persona):
    def __init__(self, nombre, edad, sueldo) -> None:
        # esta llamando al constructor de la superclase
        super().__init__(nombre, edad)  
        self.sueldo = sueldo 
        
    def info(self):
        return super().mostrarInfo() + " mi sueldo es " + str(self.sueldo)
    
    
# Crear un objeto Empleado
federico = Empleado("Federico", 45, 51000)
print(federico.info())