'''
    Una clase encapsulada tiene todos los atributos declarados
    como privados y solo se puede acceder a ellos a través de
    los metodos get y set publicos
'''

class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
    
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        if dia>0 and dia <=30 :
            self.__dia = dia
        else :
            self.__dia = 0
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        if mes>0 and mes <=12 :
            self.__mes = mes
        else :
            self.__mes = 0
            
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        if anyo >= 2022 and anyo <=2023 :
            self.__anyo = anyo
        else :
            self.__anyo = 0
            
    def mostrar(self):
        print(self.__dia, self.__mes, self.__anyo, sep="/")
            
            
# Crear fechas
hoy = Fecha(4,10,2022)
hoy.mostrar()

erronea = Fecha(-55678,543,98)
erronea.mostrar()