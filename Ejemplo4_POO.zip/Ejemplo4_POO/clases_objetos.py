# Declarar la clase Persona para dar estructura a los objetos o instancias de personas
class Persona:
    
    # Curioso, se puede declarar como argumento  por defecto
    def __init__(self, nombre, edad= 15) -> None:   
        self.nombre = nombre
        self.edad = edad

    def mostrarInfo(self):
        print("Hola, me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        

# Crear objetos o instancias de Persona
juan = Persona("Juan", 27)
maria = Persona("Maria")


# Podemos acceder a los recursos de ese objeto
juan.mostrarInfo()
maria.mostrarInfo()

# los atributos o propiedades son publicos
juan.nombre = "Juanito"
juan.edad = 28
juan.mostrarInfo()