import math

# convertir de str a int
dato = input("Dime tu edad: ")
print(type(dato))
edad = int(dato) + 1
print("Feliz cumpleaños, tienes", edad, "años")


# convertir de str a float
radio = float(input("Introduce radio del circulo: "))
print("Area del circulo", math.pi*radio**2)  # ** es una potencia
# round (que, decimales)
print("Area del circulo", round(math.pi*radio**2, 2) )

# convertir de numero a str
print("Tienes " + str(edad) + " años")

# convertir de bool a str
soltero = True
print("Estas soltero? " + str(soltero))

# convertir str a bool
mayor = input("Eres mayor de edad? ")
mayorEEE = bool(mayor)  # si la cadena esta vacia es False, sino True
print(mayorEEE, ":", type(bool(mayor)))