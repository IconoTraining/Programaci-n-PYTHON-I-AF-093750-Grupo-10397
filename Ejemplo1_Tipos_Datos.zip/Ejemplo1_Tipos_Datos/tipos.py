'''
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
num1 = 7
num2 = 4
suma = num1 + num2
print(suma)
print(suma, ":", type(suma))
print(str(suma) + ":" + str(type(suma))) #concatenar con python es complicado

# numeros reales (float)
base = 5.78
altura = 9.27
triangulo = base * altura / 2
print(triangulo, ":", type(triangulo))

# booleanos: True o False (bool)
soltero = True
print("Estas soltero?", soltero, ":", type(soltero))

# cadenas de texto (str)
# se pueden utilizar comillas simples ' o dobles ""
nombre = "Pepito"
apellido = 'Perez'
nombreCompleto = nombre + " " + apellido
print(nombreCompleto, ":", type(nombreCompleto))

