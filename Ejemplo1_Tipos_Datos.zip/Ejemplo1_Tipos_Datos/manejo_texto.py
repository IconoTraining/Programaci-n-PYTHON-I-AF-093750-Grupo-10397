texto = "Bienvenidos al curso de Python"
print(texto)

print(texto.capitalize())
print(texto.upper())
print(texto.lower())
print(texto.swapcase())

print(texto.isalnum()) # False porque tiene espacios en blanco
print('Pepito'.isalnum())
print('123456'.isalnum())
print('a1b2c3d4'.isalnum())

print(texto.isalpha()) # False porque tiene espacios en blanco
print('Pepito'.isalpha())
print('123456'.isalpha())
print('a1b2c3d4'.isalpha())

print(texto.isdigit())  # False porque no son numeros
print('123456'.isdigit())

print(texto.isupper()) # False
print('HOLA'.isupper())

print(texto.islower()) # False
print('texto de ejemplo'.islower())

ejemplo = "    lunes      "
print(ejemplo, end=".\n")
print(ejemplo.lstrip(), end=".\n")
print(ejemplo.rstrip(), end=".\n")
print(ejemplo.strip(), end=".\n")

print("Longitud:", len(texto))
print("Longitud:", texto.__len__())

print("Max:", max(texto))  # y
print("Min:", min(texto))  # espacio en blanco
print("Min:", min('a1'))   # 1

print(texto.replace('e','E'))

palabras = texto.split()
print(palabras)
print("-".join(palabras))

fecha = "3/10/2022"
datos = fecha.split('/')
print('Dia:', datos[0])
print('Mes:', datos[1])
print('año:', datos[2])

