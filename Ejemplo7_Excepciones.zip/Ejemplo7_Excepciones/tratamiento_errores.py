# try-except-else-finally

try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ValueError as ex:
    print("El valor introducido no es numerico")
    ex.with_traceback() # muestra la pila de llamadas
except ZeroDivisionError as error:    
    print("No se puede dividor por cero", error)  # muestra mensaje de error
except Exception as ex:
    print("Ha ocurrido un error", ex)
    print("Excepcion de tipo", type(ex))
else:
    # Solo se ejecuta si no hay excepciones
    print("Resultado:", round(division,2))
finally:
    # Siempre se ejecuta, haya o no excepciones
    print("*** FIN ***")
