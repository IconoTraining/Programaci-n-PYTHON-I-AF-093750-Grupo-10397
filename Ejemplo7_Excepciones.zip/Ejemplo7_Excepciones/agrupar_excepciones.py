# sumar numeros
datos = ['1', 'dos', '3', '4', '5']
suma = 0

for i in range(len(datos) + 1):
    try:
        # acceder al dato
        dato = datos[i]
        
        # lo convertimos en numero
        numero = int(dato)
    except (IndexError, ValueError, Exception) as ex:     
        print("Ha ocurrido un error", ex)
        print("Error de tipo:", type(ex))
        continue   # hace que se siga ejecutando y captura todas las excepciones
        # IMPORTANTE !!! todo lo que esta detras de continue no se ejecuta
        ex.with_traceback()
        # Si ponemos el continue aqui no funciona, ya que la traza es lo ultimo que muestra
    else:
        # lo sumamos
        suma += numero
print("Suma:", suma)